# in_class_activity_v2

###The Globe and Mail
 - Online: https://www.pressreader.com/canada/the-globe-and-mail-ottawa-quebec-edition/20241121/page/40
